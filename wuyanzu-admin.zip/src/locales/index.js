import zh from "./zh.json";
import en from "./en.json";

export { zh, en };
