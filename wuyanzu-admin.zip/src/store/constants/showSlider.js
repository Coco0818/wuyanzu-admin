export const SHOW_SLIDER = 'SHOW_SLIDER'
